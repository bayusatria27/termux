### data directories
contains several files and authorization for [ihack.py](https://github.com/termuxhackers-id/main/ihack.py)
