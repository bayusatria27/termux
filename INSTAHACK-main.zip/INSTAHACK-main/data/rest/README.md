### rest directories
contains all bruteforce results
#
```ok-date.txt``` authenticated results
#
```cp-date.txt``` checkpoint results
